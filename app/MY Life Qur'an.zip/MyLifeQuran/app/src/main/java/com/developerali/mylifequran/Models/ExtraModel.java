package com.developerali.mylifequran.Models;

public class ExtraModel {

    String imageUrl;

    public ExtraModel(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public ExtraModel() {
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}

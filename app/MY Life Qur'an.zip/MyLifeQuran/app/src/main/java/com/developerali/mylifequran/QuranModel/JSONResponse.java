package com.developerali.mylifequran.QuranModel;

public class JSONResponse {

    private SurahNamesModel[] data;

    public SurahNamesModel[] getData() {
        return data;
    }

}

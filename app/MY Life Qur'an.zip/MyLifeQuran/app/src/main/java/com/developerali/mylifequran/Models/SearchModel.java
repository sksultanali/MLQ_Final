package com.developerali.mylifequran.Models;

public class SearchModel {

    String search;

    public SearchModel(String search) {
        this.search = search;
    }

    public SearchModel() {
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }
}

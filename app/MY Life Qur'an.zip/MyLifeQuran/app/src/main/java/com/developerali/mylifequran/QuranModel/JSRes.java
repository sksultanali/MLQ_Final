package com.developerali.mylifequran.QuranModel;

public class JSRes {

    private AudioMainModel data;

    public AudioMainModel getData() {
        return data;
    }
}

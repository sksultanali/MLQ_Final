package com.developerali.mylifequran.Models;

import java.util.List;

public class QuestionsResponse {
    private List<QuestionModel> items;

    public List<QuestionModel> getItems() {
        return items;
    }
}

package com.developerali.mylifequran.Blogger;

public class Constants {

    public static final String API_Key = "AIzaSyAWYa2fRofTFJNbIawpzVLIPEisI49HNKQ";
    public static final String Blog_Id = "4534919155342970317";
    public static final String MAX_POST_RESULT = "10";




}

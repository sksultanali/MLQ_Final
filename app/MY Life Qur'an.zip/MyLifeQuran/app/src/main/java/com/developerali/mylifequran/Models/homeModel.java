package com.developerali.mylifequran.Models;

public class homeModel {

    String sunrise, sunset, fozor, johor, asor, magrib, esa, tahajjut, seheri, iftar, makru1,
            makru2, makru3, makru4, makru5, makru6;

    public homeModel(String sunrise, String sunset, String fozor, String johor,
                     String asor, String magrib, String esa, String tahajjut, String seheri,
                     String iftar, String makru1, String makru2, String makru3, String makru4, String makru5, String makru6) {
        this.sunrise = sunrise;
        this.sunset = sunset;
        this.fozor = fozor;
        this.johor = johor;
        this.asor = asor;
        this.magrib = magrib;
        this.esa = esa;
        this.tahajjut = tahajjut;
        this.seheri = seheri;
        this.iftar = iftar;
        this.makru1 = makru1;
        this.makru2 = makru2;
        this.makru3 = makru3;
        this.makru4 = makru4;
        this.makru5 = makru5;
        this.makru6 = makru6;
    }

    public homeModel() {
    }

    public String getSunrise() {
        return sunrise;
    }

    public void setSunrise(String sunrise) {
        this.sunrise = sunrise;
    }

    public String getSunset() {
        return sunset;
    }

    public void setSunset(String sunset) {
        this.sunset = sunset;
    }

    public String getFozor() {
        return fozor;
    }

    public void setFozor(String fozor) {
        this.fozor = fozor;
    }

    public String getJohor() {
        return johor;
    }

    public void setJohor(String johor) {
        this.johor = johor;
    }

    public String getAsor() {
        return asor;
    }

    public void setAsor(String asor) {
        this.asor = asor;
    }

    public String getMagrib() {
        return magrib;
    }

    public void setMagrib(String magrib) {
        this.magrib = magrib;
    }

    public String getEsa() {
        return esa;
    }

    public void setEsa(String esa) {
        this.esa = esa;
    }

    public String getTahajjut() {
        return tahajjut;
    }

    public void setTahajjut(String tahajjut) {
        this.tahajjut = tahajjut;
    }

    public String getSeheri() {
        return seheri;
    }

    public void setSeheri(String seheri) {
        this.seheri = seheri;
    }

    public String getIftar() {
        return iftar;
    }

    public void setIftar(String iftar) {
        this.iftar = iftar;
    }

    public String getMakru1() {
        return makru1;
    }

    public void setMakru1(String makru1) {
        this.makru1 = makru1;
    }

    public String getMakru2() {
        return makru2;
    }

    public void setMakru2(String makru2) {
        this.makru2 = makru2;
    }

    public String getMakru3() {
        return makru3;
    }

    public void setMakru3(String makru3) {
        this.makru3 = makru3;
    }

    public String getMakru4() {
        return makru4;
    }

    public void setMakru4(String makru4) {
        this.makru4 = makru4;
    }

    public String getMakru5() {
        return makru5;
    }

    public void setMakru5(String makru5) {
        this.makru5 = makru5;
    }

    public String getMakru6() {
        return makru6;
    }

    public void setMakru6(String makru6) {
        this.makru6 = makru6;
    }
}

package com.developerali.mylifequran.QuranModel;

public class DetailedRespons {

    private detailedData data;

    public detailedData getData() {
        return data;
    }
}
